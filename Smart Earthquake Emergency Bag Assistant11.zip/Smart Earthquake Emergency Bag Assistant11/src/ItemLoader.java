import java.io.*;
import java.util.*;

public class ItemLoader {

    public static List<Item> loadItems(String filename) {
        List<Item> items = new ArrayList<>();

        File file = new File(filename);
        if (!file.exists()) {
            System.out.println("File not found: " + filename);
            return items;
        }

        try (Scanner scanner = new Scanner(file)) {
            int lineNumber = 0;

            while (scanner.hasNextLine()) {
                lineNumber++;
                String line = scanner.nextLine().trim();

                if (line.isEmpty()) continue;

                                String[] parts = line.split(";");

                if (parts.length != 2) {
                    System.out.println(
                        "Invalid format at line " + lineNumber +
                        " in " + filename + ": " + line
                    );
                    continue;
                }

                String name = parts[0];
                double weight = Double.parseDouble(parts[1]);

                items.add(new Item(name, weight));
            }

        } catch (Exception e) {
            System.out.println("Error reading file: " + filename);
        }

        return items;
    }

    public static void displayFileContent(String filename) {
        List<Item> items = loadItems(filename);

        if (items.isEmpty()) {
            System.out.println("File is empty or not found.");
            return;
        }

        for (Item item : items) {
            System.out.printf("- %s (%.2f kg)%n",
                    item.getName(), item.getWeight());
        }
    }

    public static void appendItem(String filename, String name, double weight) {
        try (FileWriter writer = new FileWriter(filename, true)) {
            writer.write(name + ";" + weight + System.lineSeparator());
            System.out.println("✔ Item added successfully.");
        } catch (IOException e) {
            System.out.println("Error writing to file: " + filename);
        }
    }
}
