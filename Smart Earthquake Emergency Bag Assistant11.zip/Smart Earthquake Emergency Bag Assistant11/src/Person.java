import java.util.ArrayList;
import java.util.List;

public abstract class Person {
    private String name;
    private List<Item> personalItems;
    
    public Person(String name) {
        this.name = name;
        this.personalItems = new ArrayList<>();
    }
    
    public String getName() {
        return name;
    }
    
    public List<Item> getPersonalItems() {
        return personalItems;
    }
    
    public void loadPersonalItems() {
        String filename = getCategoryFilename();
        List<Item> items = ItemLoader.loadItems(filename);
        personalItems.clear();
        personalItems.addAll(items);
    }
    
    public abstract String getCategory();
    public abstract String getCategoryFilename();
    
   
    public String toString() {
        return String.format("- %s (%s)", name, getCategory());
    }
}