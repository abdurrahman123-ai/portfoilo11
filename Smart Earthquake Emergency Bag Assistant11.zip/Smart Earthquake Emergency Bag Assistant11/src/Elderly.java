public class Elderly extends Person {
    public Elderly(String name) {
        super(name);
    }
    
   
    public String getCategory() {
        return "Elderly";
    }
    
   
    public String getCategoryFilename() {
        return "data/elderly_items.txt";
    }
}