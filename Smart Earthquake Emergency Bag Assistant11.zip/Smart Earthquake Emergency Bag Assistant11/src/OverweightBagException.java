public class OverweightBagException extends Exception {
    private Item item;
    private double currentWeight;
    private double maxCapacity;
    
    public OverweightBagException(Item item, double currentWeight, double maxCapacity) {
        super(String.format("Cannot add '%s' (%,.2f kg). Current: %,.2f kg, Max: %,.2f kg",
            item.getName(), item.getWeight(), currentWeight, maxCapacity));
        this.item = item;
        this.currentWeight = currentWeight;
        this.maxCapacity = maxCapacity;
    }
    
    public Item getItem() {
        return item;
    }
    
    public double getCurrentWeight() {
        return currentWeight;
    }
    
    public double getMaxCapacity() {
        return maxCapacity;
    }
}