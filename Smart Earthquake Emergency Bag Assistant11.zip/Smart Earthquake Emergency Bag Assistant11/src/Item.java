public class Item implements Weighable {
    private String name;
    private double weight;
    
    public Item(String name, double weight) {
        this.name = name;
        this.weight = weight;
    }
    
   
    public double getWeight() {
        return weight;
    }
    
    public String getName() {
        return name;
    }
    
    public Item copy() {
        return new Item(this.name, this.weight);
    }
    
  
    public String toString() {
        
        return String.format("%-30s %,.2f kg", name, weight).replace('.', ',');
    }
}