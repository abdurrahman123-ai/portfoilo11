public enum RiskLevel {
    HIGH, MEDIUM, LOW;
    
    public static RiskLevel fromInt(int choice) {
        switch(choice) {
            case 1: return HIGH;
            case 2: return MEDIUM;
            case 3: return LOW;
            default: return MEDIUM;
        }
    }
    
    public String getFilename() {
        return "data/base_items_" + this.toString().toLowerCase() + ".txt";
    }
    
    public String toStringFormatted() {
        switch(this) {
            case HIGH: return "HIGH";
            case MEDIUM: return "MEDIUM";
            case LOW: return "LOW";
            default: return "MEDIUM";
        }
    }
}