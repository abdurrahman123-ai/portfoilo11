public class Adult extends Person {
    public Adult(String name) {
        super(name);
    }
    
   
    public String getCategory() {
        return "Adult";
    }
    
   
    public String getCategoryFilename() {
        return "data/adult_items.txt";
    }
}