public class Baby extends Person {
    public Baby(String name) {
        super(name);
    }
    
   
    public String getCategory() {
        return "Baby";
    }
    
    
    public String getCategoryFilename() {
        return "data/baby_items.txt";
    }
}
