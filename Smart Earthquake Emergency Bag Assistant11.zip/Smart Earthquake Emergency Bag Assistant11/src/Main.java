import java.util.*;
import java.util.Locale;


public class Main {
	
    private static Scanner scanner = new Scanner(System.in);
    private static final String DIVIDER = "=".repeat(50);
    
    public static void main(String[] args) {
    	
    	

    	    System.out.println(DIVIDER);
    	    System.out.println("     SMART EARTHQUAKE EMERGENCY BAG ASSISTANT     ");
    	    System.out.println(DIVIDER + "\n");
    	    
    	    
    	    
       
        
        while (true) {
            displayMainMenu();
            int choice = getIntInput("Your choice: ");
            
            switch (choice) {
                case 1:
                    createNewBag();
                    break;
                case 2:
                    addNewItemToCategory();
                    break;
                case 3:
                    viewCategoryItems();
                    break;
                case 0:
                    System.out.println("\nThank you for using the Smart Earthquake Emergency Bag Assistant!");
                    System.out.println("Stay safe and prepared!");
                    scanner.close();
                    return;
                default:
                    System.out.println(" Invalid choice! Please enter 0-3.");
            }
            
            pause();
        }
    }
    
    private static void displayMainMenu() {
        System.out.println("\n" + DIVIDER);
        System.out.println("                     MAIN MENU                    ");
        System.out.println(DIVIDER);
        System.out.println("1 - Create New Earthquake Bag");
        System.out.println("2 - Add New Item to Category");
        System.out.println("3 - View Category Items");
        System.out.println("0 - Exit");
        System.out.println(DIVIDER);
    }
    
    private static void createNewBag() {
        System.out.println("\n" + DIVIDER);
        System.out.println("           CREATE NEW EARTHQUAKE BAG           ");
        System.out.println(DIVIDER);
        
        // 1. enter familly number 
        int familySize = getIntInput("\nHow many family members are there? ");
        while (familySize <= 0) {
            System.out.println(" Number must be at least 1!");
            familySize = getIntInput("How many family members are there? ");
        }
        // data for evry indivisiual
        List<Person> familyMembers = new ArrayList<>();
        System.out.println("\n" + "-".repeat(40));
        
        for (int i = 0; i < familySize; i++) {
            System.out.printf("\n--- Family Member %d ---%n", i + 1);
            String name = getStringInput("Person's name: ");
            
            System.out.println("Select category:");
            System.out.println("1 - Adult");
            System.out.println("2 - Elderly");
            System.out.println("3 - Baby");
            System.out.println("4 - Chronic Patient");
            
            int categoryChoice = getIntInput("Choice (1-4): ");
            while (categoryChoice < 1 || categoryChoice > 4) {
                System.out.println("❌ Invalid choice! Enter 1-4");
                categoryChoice = getIntInput("Choice (1-4): ");
            }
            
            Person person = createPerson(name, categoryChoice);
            familyMembers.add(person);
        }
        
        // 3.chose emergency level
        System.out.println("\n" + "-".repeat(40));
        System.out.println("\nRisk level:");
        System.out.println("1 - HIGH");
        System.out.println("2 - MEDIUM");
        System.out.println("3 - LOW");
        
        int riskChoice = getIntInput("Choice (1-3): ");
        while (riskChoice < 1 || riskChoice > 3) {
            System.out.println("❌ Invalid choice! Enter 1-3");
            riskChoice = getIntInput("Choice (1-3): ");
        }
        
        RiskLevel riskLevel = RiskLevel.fromInt(riskChoice);
        System.out.printf("Selected risk level: %s%n", riskLevel.toStringFormatted());
        
        // 4.   maximum capacity
        System.out.println("\n" + "-".repeat(40));
        double maxCapacity = getDoubleInput("\nBag capacity (kg): ");
        while (maxCapacity <= 0) {
            System.out.println(" Capacity must be positive!");
            maxCapacity = getDoubleInput("Bag capacity (kg): ");
        }
        
        // 5. create bag and add items   
        System.out.println("\n" + DIVIDER);
        System.out.println("           LOADING EMERGENCY BAG ITEMS          ");
        System.out.println(DIVIDER);
        
        EmergencyBag bag = new EmergencyBag(maxCapacity);
        
        
        for (Person person : familyMembers) {
            System.out.println("\n" + "-".repeat(40));
            System.out.printf("Processing items for: %s (%s)%n", 
                person.getName(), person.getCategory());
            
         
            bag.addBaseItemsForPerson(person, riskLevel);
            
            
            bag.addPersonalItemsForPerson(person);
            // total weight for evry person
            System.out.printf(Locale.GERMANY,
                    "\nCurrent Total Weight: %,.2f kg%n", bag.getCurrentWeight());
            System.out.printf(Locale.GERMANY,
                    "Maximum Capacity: %,.2f kg%n", bag.getMaxCapacity());
            System.out.println("-".repeat(40));
        }
        
        System.out.println("\n" + DIVIDER);
        System.out.println("           TOTAL BAG WEIGHT INFO           ");
        System.out.println(DIVIDER);

        System.out.printf(Locale.GERMANY,
                "Total Weight of All Items: %,.2f kg%n", bag.getCurrentWeight());
        System.out.printf(Locale.GERMANY,
                "Maximum Capacity: %,.2f kg%n", bag.getMaxCapacity());
        System.out.println(DIVIDER);

        //final result display
        System.out.println("\n" + DIVIDER);
        System.out.println("              FINAL BAG SUMMARY                ");
        System.out.println(DIVIDER);

        bag.displaySummary(familyMembers);
//display extra statics
        displayAdditionalStats(familyMembers, bag, riskLevel);
//export the information summary to txt file 
        bag.exportSummaryToFile(familyMembers, riskLevel, "outputmac.txt");
        System.out.println("\n✅ Final bag summary has been exported to outputmac.txt");
        
        
        
    }

    
    private static Person createPerson(String name, int categoryChoice) {
        switch (categoryChoice) {
            case 1: return new Adult(name);
            case 2: return new Elderly(name);
            case 3: return new Baby(name);
            case 4: return new ChronicPatient(name);
            default: return new Adult(name); 
        }
    }
    
    private static void addNewItemToCategory() {
        System.out.println("\n" + DIVIDER);
        System.out.println("         ADD NEW ITEM TO CATEGORY          ");
        System.out.println(DIVIDER);
        
        System.out.println("\nSelect category:");
        System.out.println("1 - Adult");
        System.out.println("2 - Elderly");
        System.out.println("3 - Baby");
        System.out.println("4 - Chronic Patient");
        
        int categoryChoice = getIntInput("Your choice: ");
        while (categoryChoice < 1 || categoryChoice > 4) {
            System.out.println(" Invalid choice! Enter 1-4");
            categoryChoice = getIntInput("Your choice: ");
        }
        
        String filename = getFilenameFromCategory(categoryChoice);
        String categoryName = getCategoryName(categoryChoice);
        
        System.out.printf("\nAdding item to %s category%n", categoryName);
        System.out.println("-".repeat(30));
        
        System.out.println("Current items in this category:");
        ItemLoader.displayFileContent(filename);
        
        System.out.println("\nEnter new item details:");
        String itemName = getStringInput("Item name: ");
        
        double weight = getDoubleInput("Weight (e.g., 0.5): ");
        while (weight <= 0) {
            System.out.println(" Weight must be positive!");
            weight = getDoubleInput("Weight (e.g., 0.5): ");
        }
        
        ItemLoader.appendItem(filename, itemName, weight);
        //the updated item display
        System.out.println("\nUpdated item list:");
        ItemLoader.displayFileContent(filename);
    }
    
    private static void viewCategoryItems() {
        System.out.println("\n" + DIVIDER);
        System.out.println("           VIEW CATEGORY ITEMS           ");
        System.out.println(DIVIDER);
        
        System.out.println("\nSelect category to view:");
        System.out.println("1 - Adult Items");
        System.out.println("2 - Elderly Items");
        System.out.println("3 - Baby Items");
        System.out.println("4 - Chronic Patient Items");
        System.out.println("5 - Base Items (HIGH Risk)");
        System.out.println("6 - Base Items (MEDIUM Risk)");
        System.out.println("7 - Base Items (LOW Risk)");
        System.out.println("8 - All Categories");
        System.out.println("0 - Back to Main Menu");
        
        int choice = getIntInput("Your choice: ");
        
        switch (choice) {
            case 1:
                ItemLoader.displayFileContent("data/adult_items.txt");
                break;
            case 2:
                ItemLoader.displayFileContent("data/elderly_items.txt");
                break;
            case 3:
                ItemLoader.displayFileContent("data/baby_items.txt");
                break;
            case 4:
                ItemLoader.displayFileContent("data/chronic_items.txt");
                break;
            case 5:
                ItemLoader.displayFileContent("data/base_items_high.txt");
                break;
            case 6:
                ItemLoader.displayFileContent("data/base_items_medium.txt");
                break;
            case 7:
                ItemLoader.displayFileContent("data/base_items_low.txt");
                break;
            case 8:
                System.out.println("\n--- All Item Categories ---");
                ItemLoader.displayFileContent("data/adult_items.txt");
                ItemLoader.displayFileContent("data/elderly_items.txt");
                ItemLoader.displayFileContent("data/baby_items.txt");
                ItemLoader.displayFileContent("data/chronic_items.txt");
                System.out.println("\n--- Base Items ---");
                ItemLoader.displayFileContent("data/base_items_high.txt");
                ItemLoader.displayFileContent("data/base_items_medium.txt");
                ItemLoader.displayFileContent("data/base_items_low.txt");
                break;
            case 0:
                return;
            default:
                System.out.println("❌ Invalid choice!");
        }
    }
    
    private static void displayAdditionalStats(List<Person> familyMembers, EmergencyBag bag, RiskLevel riskLevel) {
        System.out.println("\n" + "-".repeat(40));
        System.out.println("           ADDITIONAL STATISTICS           ");
        System.out.println("-".repeat(40));
        
        //statics according old
        int adultCount = 0, elderlyCount = 0, babyCount = 0, chronicCount = 0;
        
        for (Person person : familyMembers) {
            if (person instanceof Adult) adultCount++;
            else if (person instanceof Elderly) elderlyCount++;
            else if (person instanceof Baby) babyCount++;
            else if (person instanceof ChronicPatient) chronicCount++;
        }
        
        System.out.println("\nFamily Composition:");
        if (adultCount > 0) System.out.printf("  Adults: %d%n", adultCount);
        if (elderlyCount > 0) System.out.printf("  Elderly: %d%n", elderlyCount);
        if (babyCount > 0) System.out.printf("  Babies: %d%n", babyCount);
        if (chronicCount > 0) System.out.printf("  Chronic Patients: %d%n", chronicCount);
        //weight information
        double remainingCapacity = bag.getMaxCapacity() - bag.getCurrentWeight();
        double percentageUsed = (bag.getCurrentWeight() / bag.getMaxCapacity()) * 100;
        
        System.out.printf("\nWeight Information:%n");

        System.out.printf(Locale.GERMANY,
                "  Bag Capacity: %,.2f kg%n", bag.getMaxCapacity());

        System.out.printf(Locale.GERMANY,
                "  Current Weight: %,.2f kg%n", bag.getCurrentWeight());

        System.out.printf(Locale.GERMANY,
                "  Remaining Capacity: %,.2f kg%n", remainingCapacity);

        System.out.printf(Locale.GERMANY,
                "  Capacity Used: %,.1f%%%n", percentageUsed);

        //recommendations
        System.out.println("\nRecommendations:");
        switch (riskLevel) {
            case HIGH:
                System.out.println("   HIGH RISK: Consider preparing additional emergency supplies");
                System.out.println("  • Extra water and food for at least 3 days");
                System.out.println("  • Emergency communication devices");
                System.out.println("  • Important documents in waterproof container");
                break;
            case MEDIUM:
                System.out.println("   MEDIUM RISK: Standard preparedness recommended");
                System.out.println("  • Water and food for 2 days");
                System.out.println("  • First aid kit and essential medications");
                System.out.println("  • Flashlight with extra batteries");
                break;
            case LOW:
                System.out.println("  * LOW RISK: Basic preparedness sufficient");
                System.out.println("  • Water and food for 1 day");
                System.out.println("  • Basic first aid supplies");
                System.out.println("  • Emergency contact list");
                break;
        }
    }
    
    private static String getFilenameFromCategory(int category) {
        switch (category) {
            case 1: return "data/adult_items.txt";
            case 2: return "data/elderly_items.txt";
            case 3: return "data/baby_items.txt";
            case 4: return "data/chronic_items.txt";
            default: return "data/adult_items.txt";
        }
    }
    
    private static String getCategoryName(int category) {
        switch (category) {
            case 1: return "Adult";
            case 2: return "Elderly";
            case 3: return "Baby";
            case 4: return "Chronic Patient";
            default: return "Adult";
        }
    }
    
    // ========== Utility Methods ==========
    
    private static int getIntInput(String prompt) {
        while (true) {
            try {
                System.out.print(prompt);
                int value = scanner.nextInt();
                scanner.nextLine();   
                return value;
            } catch (InputMismatchException e) {
                System.out.println("❌ Invalid input! Please enter a whole number.");
                scanner.nextLine();   
            }
        }
    }
    
    private static double getDoubleInput(String prompt) {
        while (true) {
            try {
                System.out.print(prompt);
                double value = scanner.nextDouble();
                scanner.nextLine(); 
                return value;
            } catch (InputMismatchException e) {
                System.out.println("❌ Invalid input! Please enter a number.");
                scanner.nextLine(); 
            }
        }
    }
    
    private static String getStringInput(String prompt) {
        System.out.print(prompt);
        String input = scanner.nextLine().trim();
        
        while (input.isEmpty()) {
            System.out.println("❌ Input cannot be empty!");
            System.out.print(prompt);
            input = scanner.nextLine().trim();
        }
        
        return input;
    }
    
    private static void pause() {
        System.out.print("\nPress Enter to continue...");
        scanner.nextLine();
    }
}