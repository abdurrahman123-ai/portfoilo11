import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

public class EmergencyBag {

    private List<Item> items;
    private double maxCapacity;
    private double currentWeight;

    public EmergencyBag(double maxCapacity) {
        this.items = new ArrayList<>();
        this.maxCapacity = maxCapacity;
        this.currentWeight = 0.0;
    }

    //  Item Handling 

    public void addItem(Item item) throws OverweightBagException {
        double newWeight = currentWeight + item.getWeight();

        if (newWeight > maxCapacity) {
            throw new OverweightBagException(item, currentWeight, maxCapacity);
        }

        items.add(item);
        currentWeight = newWeight;

        System.out.printf(Locale.GERMANY,
                "Added: %s (Total: %,.2f kg)%n",
                item.getName(), currentWeight);
    }

    public boolean tryAddItem(Item item) {
        try {
            addItem(item);
            return true;
        } catch (OverweightBagException e) {
            System.out.println(" " + e.getMessage());
            return false;
        }
    }

    //  Loading Items 

    public void addBaseItemsForPerson(Person person, RiskLevel riskLevel) {
        System.out.printf("\nLoading base items for %s (%s):%n",
                person.getName(), person.getCategory());

        List<Item> baseItems = ItemLoader.loadItems(riskLevel.getFilename());

        for (Item item : baseItems) {
            if (!tryAddItem(item.copy())) {
                System.out.println("Stopping further additions for this person.");
                break;
            }
        }
    }

    public void addPersonalItemsForPerson(Person person) {
        System.out.printf("\nLoading personal items for %s (%s):%n",
                person.getName(), person.getCategory());

        person.loadPersonalItems();
        List<Item> personalItems = person.getPersonalItems();

        for (Item item : personalItems) {
            if (!tryAddItem(item.copy())) {
                System.out.println("Stopping further additions for this person.");
                break;
            }
        }
    }

    //  Getters 

    public double getCurrentWeight() {
        return currentWeight;
    }

    public double getMaxCapacity() {
        return maxCapacity;
    }

    public List<Item> getItems() {
        return items;
    }

    public boolean isWithinLimit() {
        return currentWeight <= maxCapacity;
    }

    //  Display Summary 

    public void displaySummary(List<Person> familyMembers) {
        System.out.println("\n=== BAG SUMMARY ===\n");

        System.out.println("Family members:");
        for (Person person : familyMembers) {
            System.out.println(person);
        }

        System.out.println("\nItems:");
        if (items.isEmpty()) {
            System.out.println("No items in the bag.");
        } else {
            for (int i = 0; i < items.size(); i++) {
                System.out.printf("%2d. %s%n", i + 1, items.get(i));
            }
        }

        System.out.printf(Locale.GERMANY,
                "\nTotal Weight: %,.2f kg%n", currentWeight);

        System.out.printf(Locale.GERMANY,
                "Maximum Capacity: %,.2f kg%n", maxCapacity);

        String status = isWithinLimit() ? "✓ Within limit" : "✗ Overweight!";
        System.out.printf("\nStatus: %s%n", status);
    }

    //  EXPORT TO FILE 

    public void exportSummaryToFile(
            List<Person> familyMembers,
            RiskLevel riskLevel,
            String filename) {

        try (PrintWriter writer = new PrintWriter(new FileWriter(filename))) {

            writer.println("SMART EARTHQUAKE EMERGENCY BAG SUMMARY");
            writer.println("=".repeat(50));

            writer.println("Risk Level: " + riskLevel.toStringFormatted());

            writer.printf(Locale.GERMANY,
                    "Bag Capacity: %,.2f kg%n", maxCapacity);

            writer.printf(Locale.GERMANY,
                    "Current Weight: %,.2f kg%n", currentWeight);

            writer.printf(Locale.GERMANY,
                    "Remaining Capacity: %,.2f kg%n",
                    (maxCapacity - currentWeight));

            writer.println("\nFamily Members:");
            writer.println("-".repeat(30));
            for (Person person : familyMembers) {
                writer.println("- " + person.getName()
                        + " (" + person.getCategory() + ")");
            }

            writer.println("\nItems in the Bag:");
            writer.println("-".repeat(30));
            if (items.isEmpty()) {
                writer.println("No items in the bag.");
            } else {
                for (int i = 0; i < items.size(); i++) {
                    Item item = items.get(i);
                    writer.printf("%2d. %s (%.2f kg)%n",
                            i + 1,
                            item.getName(),
                            item.getWeight());
                }
            }

            writer.println("\nStatus:");
            writer.println(isWithinLimit()
                    ? "* Within weight limit"
                    : "* Overweight!");

            writer.println("\nGenerated on: " + new Date());

            System.out.println("✔ Final bag summary exported to:");
            System.out.println("outputmac.txt" + filename);

        } catch (IOException e) {
            System.out.println(" Error exporting bag summary to file.");
        }
    }
}

