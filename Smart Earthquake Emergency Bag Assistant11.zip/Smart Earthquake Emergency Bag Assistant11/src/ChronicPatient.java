public class ChronicPatient extends Person {
    public ChronicPatient(String name) {
        super(name);
    }
    
    
    public String getCategory() {
        return "Chronic Patient";
    }
    
    
    public String getCategoryFilename() {
        return "data/chronic_items.txt";
    }
}
